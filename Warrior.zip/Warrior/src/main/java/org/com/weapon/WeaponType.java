package org.com.weapon;

public enum WeaponType {
	Knife, Sword, HandGun, Rifle, BowAndArrow;
}
