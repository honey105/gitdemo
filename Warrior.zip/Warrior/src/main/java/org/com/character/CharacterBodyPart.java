package org.com.character;

public enum CharacterBodyPart {
	Head, Heart, Arms, Legs;
}
