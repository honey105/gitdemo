package org.com.character;

public enum CharacterType {
	StreetFighter, Knight, Warrior, Enemy;
}
