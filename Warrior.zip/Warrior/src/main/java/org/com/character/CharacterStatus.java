package org.com.character;

public enum CharacterStatus {
	live, dead;
}
