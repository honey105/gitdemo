package org.com.command;

public class GameCommandExecuter {

	public void executeCommand(Command command) {
		command.execute();
	}

}
