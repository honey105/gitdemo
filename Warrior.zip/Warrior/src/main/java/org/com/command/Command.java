package org.com.command;

//Command
public interface Command {
	
	public void execute();
	public CommandResult getCommandResult();
	
}
