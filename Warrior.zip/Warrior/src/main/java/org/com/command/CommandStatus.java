package org.com.command;

public enum CommandStatus {
	Success, Failure, Error;
}
